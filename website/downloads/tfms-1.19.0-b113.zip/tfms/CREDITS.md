# เครดิตและสัญญาอนุญาตของส่วนประกอบที่ใช้

ระบบนี้สร้างขึ้นโดยใช้ผลงานของผู้อื่นตามรายการด้านล่าง ขอขอบคุณเจ้าของผลงานทุกท่าน
โค้ดของระบบเองเผยแพร่ภายใต้ [MIT License](LICENSE) (ไม่รวมส่วนประกอบในตารางนี้ ตราสัญลักษณ์ และรูปผู้พัฒนา)

## นโยบายการให้เครดิต
**ทุกครั้งที่นำโปรเจค ไลบรารี ฟอนต์ ข้อมูล หรือโค้ดของผู้อื่นมาใช้ ต้องให้เครดิตเสมอ** โดยในการเปลี่ยนแปลงเดียวกันที่นำของนั้นเข้ามา ต้อง:

1. เพิ่มรายการใน `data/credits.json` (ชื่อ ผู้สร้าง สัญญาอนุญาต ลิงก์ ใช้ทำอะไร และไฟล์ที่นำเข้ามา)
2. แนบไฟล์สัญญาอนุญาตต้นฉบับของเจ้าของผลงานมาด้วย และระบุใน `license_file` (คงข้อความลิขสิทธิ์ตามที่สัญญากำหนด)
3. รัน `python3 tools/sync_credits.py` เพื่อปรับไฟล์นี้และบล็อกเครดิตในเว็บประชาสัมพันธ์ (`website/index.html`) — รายการเดียวกันแสดงในหน้าต่าง "เกี่ยวกับ" ของระบบโดยอัตโนมัติ
4. ตรวจก่อนนำเข้าว่าสัญญาอนุญาตของผลงานนั้นอนุญาตให้ใช้และแจกจ่ายต่อได้ ถ้าไม่ได้ระบุสัญญาอนุญาต ให้ระบุข้อเท็จจริงนั้นตรง ๆ ในช่อง `license` (ห้ามเดา)

ชุดทดสอบ `python3 tests/run_all.py credits` ตรวจให้อัตโนมัติ: ไฟล์ใน `assets/vendor/` และ `assets/fonts/` ทุกไฟล์ต้องมีรายการเครดิต, ไฟล์สัญญาอนุญาตที่ระบุต้องมีอยู่จริง, และ CREDITS.md / เว็บประชาสัมพันธ์ต้องตรงกับ `data/credits.json`

## รายการ
| ส่วนประกอบ | ใช้ทำอะไร | ผู้สร้าง | สัญญาอนุญาต |
|---|---|---|---|
| ฟอนต์ JS Chanok | ตัวอักษรบนอนุโมทนาบัตร (ฝังในระบบ) | ไม่ระบุชื่อในไฟล์สัญญาอนุญาตที่ได้รับ | GNU GPL v2 ([ไฟล์สัญญาอนุญาต](assets/fonts/GPL-License-JS.pdf)) |
| [SweetAlert2 11.26.25](https://sweetalert2.github.io/) | กล่องข้อความแจ้งเตือนและหน้าต่างเกี่ยวกับ | Tristan Edwards & Limon Monte | MIT ([ไฟล์สัญญาอนุญาต](assets/vendor/sweetalert2.LICENSE)) |
| [qrcode-generator 2.0.4 (qrcode.js)](http://www.d-project.com/) | QR code ตรวจสอบอนุโมทนาบัตร | Kazuhiko Arase | MIT ([ไฟล์สัญญาอนุญาต](assets/vendor/qrcode.LICENSE)) |
| [Chart.js 4.6.1](https://www.chartjs.org/) | กราฟรายรับ-รายจ่ายรายเดือนและสัดส่วนหมวดบัญชีบนแดชบอร์ดและหน้ารายงาน | Chart.js Contributors | MIT ([ไฟล์สัญญาอนุญาต](assets/vendor/chart.LICENSE)) |
| [Feather Icons 4.29.2](https://github.com/feathericons/feather) | ไอคอนบนเมนู ปุ่ม และการแจ้งเตือนทั่วระบบ (ไฟล์ sprite ฝังในระบบ) | Cole Bemis | MIT ([ไฟล์สัญญาอนุญาต](assets/vendor/feather.LICENSE)) |
| [thai-banks-logo (โลโก้ธนาคารไทย)](https://github.com/casperstack/thai-banks-logo) | โลโก้ธนาคาร 19 แห่งและรายชื่อธนาคารในตัวเลือกธนาคารของบัญชีเงินฝาก (ไฟล์ PNG ต้นฉบับไม่แก้ไข) โลโก้เป็นของธนาคารเจ้าของแต่ละแห่ง ใช้เพื่อระบุธนาคารเท่านั้น | fasterv410 (ผู้เขียนตาม package.json) · ที่เก็บ casperstack/thai-banks-logo | ISC ตามที่ระบุในช่อง license ของ package.json ของโปรเจคต้นทาง (ที่เก็บต้นทางไม่มีไฟล์ LICENSE จึงแนบ package.json เป็นหลักฐาน) ([ไฟล์สัญญาอนุญาต](assets/banks/thai-banks-logo.package.json)) |
| [Tailwind CSS 3.4.17](https://tailwindcss.com/) | จัดรูปแบบหน้าเว็บ (ไฟล์ CSS ที่คอมไพล์แล้ว assets/css/tailwind.css) | Tailwind Labs, Inc. | MIT |
| [ฟอนต์ Sarabun](https://fonts.google.com/specimen/Sarabun) | ตัวอักษรหน้าเว็บ (โหลดจาก Google Fonts ตอนใช้งาน ไม่ได้ฝังในระบบ) | Cadson Demak | SIL Open Font License 1.1 |
| [thai-province-data](https://github.com/kongvut/thai-province-data) | ฐานข้อมูลจังหวัด/อำเภอ/ตำบล สำหรับตัวติดตั้งและการสร้างผู้ใช้อัตโนมัติ (data/thai_geo.json) | Kongvut Sangkla | MIT ([ไฟล์สัญญาอนุญาต](data/thai_geo.LICENSE)) |
| [ทะเบียนวัดแพร่ 381 วัด (binfo.onab.go.th)](https://binfo.onab.go.th/Temple/Temple-List-view.aspx) | ข้อมูลตั้งต้นของวัด 381 วัด (data/temples_phrae.csv) และรูปแบบไฟล์ Excel ที่นำเข้าได้ | สำนักงานพระพุทธศาสนาแห่งชาติ | ไม่ได้ระบุสัญญาอนุญาตของข้อมูล — ใช้เป็นข้อมูลอ้างอิงจากเว็บไซต์ทางการและให้เครดิตแหล่งที่มา |

_ไฟล์นี้สร้างจาก `data/credits.json` ด้วย `tools/sync_credits.py` — แก้ที่ต้นทาง ไม่แก้ที่นี่_
